module.exports = {
	'secret': 'faleopreco_eyd6bj7c',
	'database': 'mongodb://fopapi:eyd6bj7c@ds023664.mlab.com:23664/faleopreco'
};